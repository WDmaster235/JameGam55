using UnityEngine;

[CreateAssetMenu(fileName = "NewEnemyStats", menuName = "Enemies/Enemy Stats")]
public class EnemyStats : ScriptableObject
{
    public GameObject enemyPrefab;

    public int hp;
    public float speed;
    public int attack;
    public float attackCooldown;
    public int cost;
    public int milkDropAmount;
}